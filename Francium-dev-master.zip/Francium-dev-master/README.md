# Francium-Interception

**Dual Proxy Combatibility**


## How to run
```txt
git clone https://github.com/Imperialfr/Francium-dev
cd Francium-dev
npm install
npm start
```
# Discord

Join the Discord!

https://discord.gg/zNTAFD9wSj

chris is a loserrr
